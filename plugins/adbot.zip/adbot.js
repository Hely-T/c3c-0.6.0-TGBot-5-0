var fetch = global.nodemodule["node-fetch"];

var adbot = function adbot(type, data) {
	(async function () {
		var returntext = `[Info] Mọi Thông Tin Vui Lòng Liên Hệ Vào Facebook: https://www.facebook.com/DVFB.HMTG2/.
Các bạn có lòng tốt có thể Donate mình qua MoMo: 0911023689 hoặc MB Bank:7666666666664 để có kinh phí duy trì nha.
Cảm ơn các bạn đã đọc <3`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"GIOI THIEU\" by Wua'n";

data.log(onLoadText);

}
module.exports = {
    adbot: adbot
}