
var sizeObject = function(object) {
    return Object.keys(object).length;
}

var wake = function (type, data) {
    var args = data.args;
        args.shift();
		if(data.admin === true) {
        var timeStop = args[1] * 1000;
        var timeTag = args[0] * 1000;
    if (sizeObject(data.mentions) > 0) {
        if (sizeObject(data.mentions) >= 1) {
            if (!isNaN(timeStop)) {
                if(!isNaN(timeTag)) {
                    if (timeTag >= 1000) {
                    if (timeStop <= 60000) {
            for (var y in data.mentions) {
                var id = y;
            }
            var obj2 = `Kích hoạt (Wake Up) với\n\n- Thời gian mỗi lần tag là: ${timeTag / 1000}s\n- Thời gian dừng: ${timeStop / 1000}s`;
            data.facebookapi.sendMessage(`${data.prefix} ${obj2}`, data.msgdata.threadID, data.msgdata.messageID);
    
                var obj = {
                    body: "Dậy nào em yêu ❤️ @",
                    mentions: [{
                        tag: `@`,
                        id: id.slice(3)
                    }]
                }
                
            var wakeUp = setInterval(function(){
                data.facebookapi.sendMessage(obj, data.msgdata.threadID, data.msgdata.messageID);
            }, timeTag);

            setTimeout(function(){
                clearInterval(wakeUp);
            }, timeStop);
            
        } else {return {handler: 'internal', data: 'Thời gian dừng không thể trên 60s'}}
        } else {return {handler: 'internal', data: 'Thời gian tag không thể dưới 1s'}}
        } else {return {handler: 'internal', data: 'Thời gian tag hoặc dừng phải là số'}}
        } else {return {handler: 'internal', data: 'Thời gian tag hoặc dừng phải là số'}}
        } else {
            return {
			handler: 'internal',
            data: 'Bạn chỉ có thể WakeUp một người'
            }
		}
    } else {
        return {
            handler: 'internal',
            data: 'Vui lòng mention/tag ít nhất một người'
        }
    }
		} else {
			data.return({
				handler: 'internal',
				data: 'Tuổi lồn dùng'
			})
		}
}
module.exports = {
    wakeFunc : wake
}