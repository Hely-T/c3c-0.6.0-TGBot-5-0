var fetch = global.nodemodule["node-fetch"];
function onLoad(data) {

var onLoadText = "\n\n";
onLoadText += "=########################################=\n";
onLoadText += "=            You Are Impostor            =\n";
onLoadText += "=########################################=\n";
onLoadText += "= Đang tải Plugins Hd cai bot code gốc by Kaysil và được sửa lại bởi Hungcho =";

data.log(onLoadText);
data.log(data);

}
var caibot = function yeuduong(type, data) {
	(async function () {
		var returntext = `
		HƯỚNG DẪN CÀI BOT TRÊN WINDOW(7,8,10)
B1
Tải và cài đặt 2 link sau:
https://git-scm.com/download/win
https://nodejs.org/en/download/(node 14)

B2
Mở Cmd(không biết thì google)
Gõ từng dòng sau
git clone https://github.com/lequanglam/c3c.git (enter, rồi chờ tải)
cd c3c (Hoặc copy link folder nếu không đc)
npm i (chờ)
npm start
Ctrl + C (Tắt bot)
Nhập tài khoản fb vào file config.json ở folder c3c.
Lưu r đóng file.
B3
Mở lại cmd gõ
npm start
Chờ có thông báo đăng nhập trên fb rồi gõ dòng sau (nhớ duyệt thiết bị)
facebok.error.continue()
Done.
Thắc mắc LH: fb.com/hungcho28299

         `;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"caibot\" by hungcho";

data.log(onLoadText);

}
module.exports = {
	caibot: caibot
}