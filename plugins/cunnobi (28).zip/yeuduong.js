var fetch = global.nodemodule["node-fetch"];
function onLoad(data) {

var onLoadText = "\n\n";
onLoadText += "=########################################=\n";
onLoadText += "=            You Are Impostor            =\n";
onLoadText += "=########################################=\n";
onLoadText += "= Đang tải Plugins Hd cai bot code gốc by Kaysil và được sửa lại  =";

data.log(onLoadText);
data.log(data);

}
var caibot = function yeuduong(type, data) {
	(async function () {
		var returntext = `
		HƯỚNG DẪN CÀI BOT TRÊN WINDOW(7,8,10)\n
B1\n
Tải và cài đặt 2 link sau:\n
https://git-scm.com/download/win\n
https://nodejs.org/en/download/(node 14)\n

B2\n
Mở Cmd(không biết thì google)\n
Gõ từng dòng sau\n
git clone https://github.com/c3cbot/c3c-x0.git (enter, rồi chờ tải)\n
cd c3c (Hoặc copy link folder nếu không đc)\n
npm i (chờ)\n
npm start\n
Ctrl + C (Tắt bot)\n
Nhập tài khoản fb vào file config.json ở folder c3c.\n
Lưu r đóng file.\n
B3\n
Mở lại cmd gõ\n
npm start\n
Chờ có thông báo đăng nhập trên fb rồi gõ dòng sau (nhớ duyệt thiết bị)\n
facebok.error.continue()\n
Done.\n

         `;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"caibot\" by ";

data.log(onLoadText);

}
module.exports = {
	caibot: caibot
}