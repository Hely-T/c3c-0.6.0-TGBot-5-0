var fetch = global.nodemodule["node-fetch"];

var Adminbot = function Adminbot(type, data) {
	(async function () {
		var returntext = `Chủ bot : Hà Mạc Trường Giang
Link Facebook Của Hắn : https://www.facebook.com/HMTG.DVFB
ID Facebook :100053601285472
Chú ý và lời nhắc nhở : Mỗi nhóm chỉ được phép add một con bot và lưu ý rằng không được phép kick ra nhét vào tránh bị ban
Cảm ơn vì đã sử dụng sản phẩm ^3^`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"GIOI THIEU\" by Wua'n";

data.log(onLoadText);

}
module.exports = {
	Adminbot: Adminbot
}