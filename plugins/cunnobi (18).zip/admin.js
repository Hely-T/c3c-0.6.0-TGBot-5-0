var fetch = global.nodemodule["node-fetch"];

var admin = function admin(type, data) {
	(async function () {
		var returntext = `chào mừng các bạn đã tìm hiểu đến đây
Thông Tin ADMIN Bot Này
𝗔𝗗𝗠𝗜𝗡 𝗡𝗔𝗠𝗘 : Hà Mạc Trường Giang
𝑩𝒊𝒆̣̂𝒕 𝒅𝒂𝒏𝒉 : BOT / HelyT
𝑮𝒊𝒐̛́𝒊 𝒕𝒉𝒊𝒆̣̂𝒖 : Đơn giản mình là bot vì chơi cãi gì cũng ngu như bot
Đặc Biệt Hơn Mình Là 1 Trapboy Xịn xò ;)
𝗧𝗶́𝗻𝗵 𝗰𝗮́𝗰𝗵 : Vui vẻ nhưng đôi lúc hơi khó tính
𝗖𝗵𝗶𝗲̂̀𝘂 𝗰𝗮𝗼 : 1m83
𝑺𝒊𝒏𝒉 𝑵𝒈𝒂̀𝒚 : 15-11-2001
𝑳𝒊𝒆̂𝒏 𝑯𝒆̣̂ : 0911023689
𝑰𝒏𝒔𝒕𝒂𝒓𝒈𝒓𝒂𝒎 : yang._.24
𝑺𝒐̛̉ 𝑻𝒉𝒊́𝒄𝒉 : Nghe nhạc,chơi game
 ngủ nướng
𝑪𝒂̂𝒏 𝑵𝒂̣̆𝒏𝒈 : 58kg
𝐈𝐃 𝐅𝐚𝐜𝐞𝐛𝐨𝐨𝐤 : 626463485 
𝗡𝗮𝗺𝗲 𝗜𝗗 : DVFB.HMTG2
𝐋𝐢𝐧𝐤 𝐟𝐚𝐜𝐞𝐛𝐨𝐨𝐤 𝐚𝐝𝐦𝐢𝐧 : https://www.facebook.com/HMTG.DVFB
Các bạn có lòng tốt có thể donate mình qua momo: 0911023689
𝑽𝒂̀𝒊 𝒍𝒐̛̀𝒊 𝒕𝒐̛́𝒊 𝒃𝒂̣𝒏 𝒅𝒖̀𝒏𝒈 : Vui lòng không spam khi sử dụng và trân thành cảm ơn bạn đã sử dụng sản phẩm
𝙇𝙪̛𝙪 𝙮́ : Đừng có dại dột mà add 2 bot kẻo bị phát hiện là bạn toang đó ❤
𝑪𝒂̉𝒏𝒉 𝒃𝒂́𝒐 : Vui lòng không dùng bot với mục đích xấu hay cố ý report acc facebook
Chúc bạn sử dụng vui vẻ ❤
Tiện đây mọi người có lòng thì cho mình xin ít tiền donate để ăn mì qua ngày với ạ :( \n MB Bank:7666666666664\nMoMo:0911023689
Hà Mạc Trường Giang chào thân ái <3 `;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"GIOI THIEU\" by Wua'n";

data.log(onLoadText);

}
module.exports = {
	admin: admin
}