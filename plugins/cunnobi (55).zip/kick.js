var wait = global.nodemodule["wait-for-stuff"];
var kick = function(type, data){
	var [err, threadInfo] = wait.for.function(data.facebookapi.getThreadInfo, data.msgdata.threadID);
	var adminIDs = threadInfo.adminIDs.map(x => x.id.toString());
	if (adminIDs.indexOf(data.msgdata.senderID) != -1) {
	    for (var y in data.mentions) {
		    var id = y;
		    console.log(id);
	        if(id != "FB-"+data.facebookapi.getCurrentUserID()){
	            data.facebookapi.removeUserFromGroup(id.slice(3,id.length),data.msgdata.threadID);
	    	}
		}
    }
	else {
		data.facebookapi.removeUserFromGroup(data.msgdata.senderID,data.msgdata.threadID);
		return{
			handler: "internal",
			data :"Địt mẹ quyền đâu mà dùng hả bạn :) ?, cút.",
		}
	}
}

module.exports = {
    kick
}